
const navLinks = [
    {
        id : 1,
        name: "Home",
        to: "/",
        category : "Home"
    },

    {
        id : 2,
        name: "Bollywood",
        to: "/Bollywood",
        category : "Bollywood"
    },

    {
        id : 3,
        name: "Fitness",
        to: "/Fitness",
        category : "Fitness"
    },

    {
        id : 4,
        name: "Hollywood",
        to: "/Hollywood",
        category : "Hollywood"
    },

    {
        id : 5,
        name: "Travel",
        to: "/Travel",
        category : "Travel"
    },

    {
        id : 6,
        name: "Food",
        to: "/Food",
        category : "Food"
    },
]
export default navLinks;