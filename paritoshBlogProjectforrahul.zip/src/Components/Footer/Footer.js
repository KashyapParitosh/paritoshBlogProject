import './Footer.css';
import React from "react";

function Footer() {


    return (
        <div className="Footer-Container">
            <footer>
                Paritosh Kashyap | 2021 All Rights Reserved.</footer>
        </div >
    );
}

export default Footer;
